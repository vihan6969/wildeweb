const fs = require('fs');
fetch('https://map.wilden.fun/assets/index-Ug_lD-Kt.js')
  .then(r => r.text())
  .then(t => {
    fs.writeFileSync('squaremap.js', t);
    console.log('Saved squaremap.js');
  })
  .catch(console.error);
