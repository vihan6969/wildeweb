const puppeteer = require('puppeteer');
(async () => {
  const browser = await puppeteer.launch();
  const page = await browser.newPage();
  await page.goto('http://localhost:3000/map', {waitUntil: 'networkidle2'});
  const mapFrame = page.frames().find(f => f.url().includes('map-api'));
  if(mapFrame) {
    const keys = await mapFrame.evaluate(() => Object.keys(window).filter(k => k !== 'webkitStorageInfo'));
    console.log(keys.filter(k => k.toLowerCase().includes('map') || k.toLowerCase().includes('pl3x') || k.toLowerCase().includes('leaflet')));
  }
  await browser.close();
})();
