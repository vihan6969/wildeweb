'use server';

export async function fetchOnlinePlayers() {
  try {
    const res = await fetch('https://map.wilden.fun/tiles/players.json', {
      next: { revalidate: 3 } // Cache for 3 seconds
    });
    const data = await res.json();
    return data;
  } catch (err) {
    console.error('Error fetching players:', err);
    return { players: [], max: 0 };
  }
}
