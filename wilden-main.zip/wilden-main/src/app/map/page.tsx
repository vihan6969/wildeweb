import { Navbar } from '@/components/Navbar';
import { Metadata } from 'next';
import { MapClient } from './MapClient';

export const metadata: Metadata = {
  title: 'Live Map | Wilden',
  description: 'View the live interactive map of the Wilden server.',
};

export default function MapPage() {
  return (
    <div className="flex flex-col h-screen w-full overflow-hidden bg-[var(--primary-bg)]">
      <Navbar />
      <MapClient />
    </div>
  );
}
