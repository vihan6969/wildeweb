'use client';

import { MapSidebar } from '@/components/MapSidebar';
import { useRef, useEffect, useState } from 'react';

export function MapClient() {
  const iframeRef = useRef<HTMLIFrameElement>(null);

  const handlePlayerClick = (player: any) => {
    const newHash = `#${player.world};${player.x};${player.z};max`;
    if (iframeRef.current) {
      iframeRef.current.src = `/map-api/index.html?show_sidebar=false${newHash}`;
    }
  };

  const [isIframeReady, setIsIframeReady] = useState(false);

  useEffect(() => {
    let animationFrameId: number;
    
    const checkIframe = () => {
      if (iframeRef.current && iframeRef.current.contentDocument) {
        try {
          const doc = iframeRef.current.contentDocument;
          if (!doc.getElementById('custom-map-style')) {
            const style = doc.createElement('style');
            style.id = 'custom-map-style';
            style.innerHTML = `
              /* Move everything down to avoid navbar */
              .leaflet-top, .leaflet-top.leaflet-left, .leaflet-top.leaflet-right {
                top: 75px !important;
              }
              
              /* Theme the controls (zoom buttons, layer icon, coordinates) */
              .leaflet-bar, .leaflet-control-layers, .leaflet-control-coordinates, .leaflet-control {
                background-color: rgba(19, 19, 22, 0.7) !important;
                backdrop-filter: blur(12px) !important;
                border: 1px solid #27272a !important;
                color: #a1a1aa !important;
                border-radius: 0.5rem !important;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1) !important;
                transition: all 150ms ease-in-out !important;
              }
              
              /* Style individual zoom buttons */
              .leaflet-bar a, .leaflet-control-layers-toggle {
                background-color: transparent !important;
                color: #fafafa !important;
                border-bottom: 1px solid #27272a !important;
                transition: all 150ms ease-in-out !important;
              }
              .leaflet-bar a:hover, .leaflet-control-layers-toggle:hover {
                background-color: rgba(159, 206, 54, 0.15) !important;
                color: #9fce36 !important;
              }
              .leaflet-bar a:last-child {
                border-bottom: none !important;
              }

              /* Layer menu expanded */
              .leaflet-control-layers-expanded {
                background-color: #131316 !important;
                color: #fafafa !important;
                border: 1px solid rgba(159, 206, 54, 0.3) !important;
                border-radius: 0.5rem !important;
              }
              
              /* Fix Layer Menu text and mouse-over */
              .leaflet-control-layers-expanded label {
                display: flex !important;
                align-items: center !important;
                padding: 4px 8px !important;
                border-radius: 4px !important;
                transition: background-color 150ms !important;
              }
              .leaflet-control-layers-expanded label:hover {
                background-color: rgba(255, 255, 255, 0.05) !important;
              }

              /* Custom Checkboxes */
              input.leaflet-control-layers-selector {
                appearance: none !important;
                -webkit-appearance: none !important;
                width: 16px !important;
                height: 16px !important;
                min-width: 16px !important;
                border: 1px solid #27272a !important;
                border-radius: 4px !important;
                background-color: rgba(19, 19, 22, 0.7) !important;
                margin: 0 !important;
                margin-right: 8px !important;
                position: relative !important;
                cursor: pointer !important;
                transition: all 150ms !important;
              }
              input.leaflet-control-layers-selector:checked {
                background-color: rgba(159, 206, 54, 0.2) !important;
                border-color: #9fce36 !important;
              }
              input.leaflet-control-layers-selector:checked::after {
                content: '' !important;
                position: absolute !important;
                left: 5px !important;
                top: 2px !important;
                width: 4px !important;
                height: 8px !important;
                border: solid #9fce36 !important;
                border-width: 0 2px 2px 0 !important;
                transform: rotate(45deg) !important;
              }

              /* Hide link button entirely */
              .link, a[title*='link' i], a[title*='Link'], a.leaflet-control-link, .leaflet-control-coordinates svg {
                display: none !important;
              }
            `;
            doc.head.appendChild(style);
            
            // Mark iframe as styled and ready!
            setIsIframeReady(true);
          } else {
            // Already injected
            setIsIframeReady(true);
          }
        } catch (e) {
          // Ignore, keep polling
        }
      }
      
      // Continue polling extremely fast (60 times a second) until ready
      if (!isIframeReady) {
        animationFrameId = requestAnimationFrame(checkIframe);
      }
    };

    animationFrameId = requestAnimationFrame(checkIframe);

    return () => cancelAnimationFrame(animationFrameId);
  }, [isIframeReady]);

  return (
    <div className="flex-grow w-full relative h-full">
      {/* Container with pointer-events-none so users can drag the map */}
      <div className="absolute inset-0 pointer-events-none z-10 overflow-hidden">
        <MapSidebar onPlayerClick={handlePlayerClick} />
      </div>

      <iframe
        ref={iframeRef}
        src="/map-api/index.html?show_sidebar=false" 
        title="Wilden Live Map"
        className={`absolute inset-0 w-full h-full border-0 z-0 transition-opacity duration-300 ${isIframeReady ? 'opacity-100' : 'opacity-0'}`}
        allowFullScreen
      />
    </div>
  );
}
