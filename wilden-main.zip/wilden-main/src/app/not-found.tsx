"use client";

import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { Rabbit } from 'lucide-react';
import { buttonVariants } from 'fumadocs-ui/components/ui/button';
import { cn } from '@/lib/cn';

export default function NotFound() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isHovered, setIsHovered] = useState(false);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      containerRef.current.style.setProperty('--mouse-x', `${x}px`);
      containerRef.current.style.setProperty('--mouse-y', `${y}px`);
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <div 
      ref={containerRef}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="flex flex-col items-center justify-center flex-1 min-h-[70vh] text-center px-4 overflow-hidden relative"
    >
      
      {/* Interactive Background */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        {/* Subtle dotted/grid pattern */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808015_1px,transparent_1px),linear-gradient(to_bottom,#80808015_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_at_center,black_40%,transparent_100%)]"></div>
        
        {/* Dynamic Spotlight Effect */}
        <div 
          className="absolute inset-0 transition-opacity duration-700 ease-in-out"
          style={{
            opacity: isHovered ? 1 : 0,
            background: 'radial-gradient(800px circle at var(--mouse-x, 50%) var(--mouse-y, 50%), rgba(129, 140, 248, 0.12), transparent 40%)',
          }}
        />
        <div 
          className="absolute inset-0 transition-opacity duration-500 ease-in-out"
          style={{
            opacity: isHovered ? 1 : 0,
            background: 'radial-gradient(400px circle at var(--mouse-x, 50%) var(--mouse-y, 50%), rgba(192, 132, 252, 0.12), transparent 40%)',
          }}
        />
      </div>

      <div className="flex flex-col items-center gap-6 max-w-md relative z-10">
        <div className="p-4 rounded-full bg-fd-secondary/50 text-fd-muted-foreground ring-1 ring-fd-border">
          <Rabbit className="w-16 h-16" strokeWidth={1.5} />
        </div>
        
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tight text-fd-foreground">
            Page Not Found
          </h1>
          <p className="text-fd-muted-foreground">
            It looks like you've wandered down the wrong rabbit hole. The page you are looking for doesn't exist.
          </p>
        </div>
        
        <Link 
          href="/docs" 
          className={cn(buttonVariants({ color: 'primary' }), "mt-4 transition-transform active:scale-95")}
        >
          Return to Documentation
        </Link>
      </div>
    </div>
  );
}






