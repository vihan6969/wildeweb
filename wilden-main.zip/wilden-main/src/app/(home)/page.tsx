import Link from 'next/link';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { HeroServer } from '@/components/HeroServer';
import fs from 'fs';
import path from 'path';
import yaml from 'yaml';

export default function HomePage() {
  const teamFilePath = path.join(process.cwd(), 'content', 'team.yml');
  let members = [];
  try {
    const teamFile = fs.readFileSync(teamFilePath, 'utf8');
    const teamData = yaml.parse(teamFile);
    members = teamData?.members || [];
  } catch (error) {
    console.error('Failed to read team.yml:', error);
  }

  return (
    <>
      <Navbar />

      <main className="main-content">
        {/* Hero Section */}
        <section className="hero">
          <div className="hero-container">
            <div className="hero-logo">
              <img src="/media/logo.webp" alt="Wilden" className="hero-logo-img" />
            </div>
            <h1 className="hero-title">
              Minecraft, like <span className="hero-accent">never before</span>.
            </h1>
            <p className="hero-description">
              Experience the ultimate Minecraft server with custom features, ranks, and an amazing community.
            </p>
            <HeroServer />
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="features">
          <div className="container">
            <h2 className="section-title">What We Offer</h2>
            <div className="features-grid">
              
              <div className="feature-card">
                <div className="feature-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 9.9-1"></path></svg>
                </div>
                <div className="feature-info">
                  <h3 className="feature-title">Cracked Support</h3>
                  <p className="feature-description">Join with cracked accounts - no premium required!</p>
                </div>
              </div>

              <div className="feature-card">
                <div className="feature-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="6" width="20" height="12" rx="2" ry="2"></rect><path d="M6 12h4"></path><path d="M8 10v4"></path><line x1="15" y1="13" x2="15.01" y2="13"></line><line x1="18" y1="11" x2="18.01" y2="11"></line></svg>
                </div>
                <div className="feature-info">
                  <h3 className="feature-title">Cross Platform</h3>
                  <p className="feature-description">Play on both Java and Bedrock editions seamlessly.</p>
                </div>
              </div>

              <div className="feature-card">
                <div className="feature-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>
                </div>
                <div className="feature-info">
                  <h3 className="feature-title">Lifesteal</h3>
                  <p className="feature-description">Steal hearts from your enemies in epic battles.</p>
                </div>
              </div>

              <div className="feature-card">
                <div className="feature-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M8.5 14.5A2.5 2.5 0 0011 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 11-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 002.5 2.5z"></path></svg>
                </div>
                <div className="feature-info">
                  <h3 className="feature-title">Elemental Bending</h3>
                  <p className="feature-description">Master the elements with our custom bending system.</p>
                </div>
              </div>

              <div className="feature-card">
                <div className="feature-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                </div>
                <div className="feature-info">
                  <h3 className="feature-title">Custom Ranks</h3>
                  <p className="feature-description">Unlock unique ranks with special perks and abilities.</p>
                </div>
              </div>

              <div className="feature-card">
                <div className="feature-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"></circle><path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8"></path><line x1="12" y1="18" x2="12" y2="22"></line><line x1="12" y1="2" x2="12" y2="6"></line></svg>
                </div>
                <div className="feature-info">
                  <h3 className="feature-title">Economy System</h3>
                  <p className="feature-description">Trade, earn, and spend in our balanced economy.</p>
                </div>
              </div>

            </div>
          </div>
        </section>

        {/* Discord Section */}
        <section id="discord" className="discord">
          <div className="container">
            <div className="discord-content">
              <div className="discord-info">
                <h2 className="section-title">Join Our Community</h2>
                <div className="discord-features">
                  <div className="discord-feature">
                    <svg className="discord-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-2-2V10a2 2 0 012-2h8z"></path>
                    </svg>
                    <span>Chat with other players</span>
                  </div>
                  <div className="discord-feature">
                    <svg className="discord-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    <span>Get support and updates</span>
                  </div>
                  <div className="discord-feature">
                    <svg className="discord-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z"></path>
                    </svg>
                    <span>Participate in events</span>
                  </div>
                </div>
                <Link href="https://discord.gg/wilden" className="btn btn-primary">Join Discord</Link>
              </div>
              <div className="discord-banner">
                <img src="/media/dc_banner.webp" alt="Discord Banner" className="discord-banner-img" />
              </div>
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section id="about" className="team">
          <div className="container">
            <h2 className="section-title">Meet Our Team</h2>
            <div className="team-grid">
              {members.map((member: any, idx: number) => (
                <div className="team-member" key={idx}>
                  <div className="team-avatar">
                    <img src={`https://mc-heads.net/head/${member.username}/100`} alt={member.name} />
                  </div>
                  <div className="team-info">
                    <h3 className="team-name">{member.name}</h3>
                    <div className={`team-role ${member.rank}`}>{member.rank.replace('-', ' ').toUpperCase()}</div>
                    <p className="team-description">{member.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Join Section */}
        <section id="join" className="join">
          <div className="container">
            <h2 className="section-title">How to Join</h2>
            <div className="join-grid">
              <div className="join-card">
                <h3 className="join-title">Java Edition</h3>
                <div className="join-details">
                  <div className="join-detail">
                    <span className="join-label">Server IP:</span>
                    <span className="join-value">wilden.fun</span>
                  </div>
                  <div className="join-detail">
                    <span className="join-label">Version:</span>
                    <span className="join-value">1.21.1</span>
                  </div>
                </div>
              </div>
              <div className="join-card">
                <h3 className="join-title">Bedrock Edition</h3>
                <div className="join-details">
                  <div className="join-detail">
                    <span className="join-label">Server IP:</span>
                    <span className="join-value">wilden.fun</span>
                  </div>
                  <div className="join-detail">
                    <span className="join-label">Port:</span>
                    <span className="join-value">19132</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
}
