import { notFound } from 'next/navigation';
import Link from 'next/link';
import { newsSource } from '@/lib/source';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';

export default async function NewsArticlePage(props: {
  params: Promise<{ slug: string }>;
}) {
  const params = await props.params;
  const page = newsSource.getPage([params.slug]);

  if (!page) {
    notFound();
  }

  const MDX = page.data.body;

  const dateStr = new Date(page.data.date ?? '').toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return (
    <>
      <Navbar />

      <main className="main-content article-page">
        <div className="container" style={{ maxWidth: '800px' }}>
          <Link href="/news" className="back-btn">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="19" y1="12" x2="5" y2="12"></line>
              <polyline points="12 19 5 12 12 5"></polyline>
            </svg>
            Back to News
          </Link>

          <article className="article-body">
            <header className="article-header">
              <h1 className="article-title">{page.data.title}</h1>
              <div className="article-meta">
                <span>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                    <line x1="16" y1="2" x2="16" y2="6"></line>
                    <line x1="8" y1="2" x2="8" y2="6"></line>
                    <line x1="3" y1="10" x2="21" y2="10"></line>
                  </svg>
                  {dateStr}
                </span>
                <span>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                    <circle cx="12" cy="7" r="4"></circle>
                  </svg>
                  Development Team
                </span>
              </div>
            </header>

            <MDX />
          </article>
        </div>
      </main>

      <Footer />
    </>
  );
}

export function generateStaticParams() {
  return newsSource.getPages().map((page) => ({
    slug: page.slugs[0],
  }));
}

export async function generateMetadata(props: {
  params: Promise<{ slug: string }>;
}) {
  const params = await props.params;
  const page = newsSource.getPage([params.slug]);

  if (!page) {
    return {};
  }

  return {
    title: `${page.data.title} | Wilden News`,
    description: page.data.description,
  };
}
