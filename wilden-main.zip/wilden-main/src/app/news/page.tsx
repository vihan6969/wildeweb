import Link from 'next/link';
import { newsSource } from '@/lib/source';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';

export default function NewsPage() {
  // Fetch all news pages
  const newsPages = newsSource.getPages().sort((a, b) => {
    const dateA = new Date(a.data.date ?? 0).getTime();
    const dateB = new Date(b.data.date ?? 0).getTime();
    return dateB - dateA;
  });

  return (
    <>
      <Navbar />

      <main className="main-content">
        <header className="news-header">
          <div className="container">
            <div className="news-logo">
              <img src="/media/logo.webp" alt="Wilden" className="news-logo-img" />
            </div>
            <h1 className="news-title">Latest News</h1>
            <p className="news-subtitle">Stay up to date with the latest updates, events, and announcements from the Wilden network.</p>
          </div>
        </header>

        <section className="news-section">
          <div className="container">
            <div className="news-grid">
              
              {newsPages.map((page) => (
                <Link key={page.url} href={page.url} className="news-card">
                  <div className="news-image">
                    {page.data.image ? (
                      <img src={page.data.image} alt={page.data.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    ) : (
                      <span>{page.data.title}</span>
                    )}
                  </div>
                  <div className="news-content">
                    <div className="news-date">
                      {new Date(page.data.date ?? '').toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric'
                      })}
                    </div>
                    <h3 className="news-card-title">{page.data.title}</h3>
                    <p className="news-excerpt">{page.data.description}</p>
                    <div className="news-read-more">
                      Read Article
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
                    </div>
                  </div>
                </Link>
              ))}

            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
}
