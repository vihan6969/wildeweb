'use client';

import { useActionState } from 'react';
import { loginAction } from './actions';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';

const initialState = {
  error: '',
};

export default function AdminLogin() {
  const [state, formAction, isPending] = useActionState(loginAction, initialState);

  return (
    <>
      <Navbar />
      <main className="flex-grow flex items-center justify-center min-h-[calc(100vh-200px)]">
        <div className="w-full max-w-md p-8 bg-[var(--card-bg)] border border-[var(--border-color)] rounded-xl shadow-xl">
          <h1 className="text-2xl font-bold text-center text-[var(--text-primary)] mb-6">Admin Access</h1>
          
          <form action={formAction} className="flex flex-col gap-4">
            <div>
              <label htmlFor="key" className="block text-sm font-medium text-[var(--text-secondary)] mb-1">
                Admin Key
              </label>
              <input
                type="password"
                id="key"
                name="key"
                required
                className="w-full px-4 py-2 bg-[var(--secondary-bg)] border border-[var(--border-color)] rounded-md text-[var(--text-primary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-primary)] focus:border-transparent transition-all"
                placeholder="Enter secret key..."
              />
            </div>
            
            {state?.error && (
              <div className="text-red-400 text-sm bg-red-400/10 p-3 rounded-md border border-red-400/20">
                {state.error}
              </div>
            )}
            
            <button
              type="submit"
              disabled={isPending}
              className="w-full py-2.5 px-4 bg-[var(--accent-primary)] hover:bg-[var(--accent-hover)] text-[var(--primary-bg)] font-semibold rounded-md transition-colors disabled:opacity-50 mt-2"
            >
              {isPending ? 'Verifying...' : 'Enter Docs'}
            </button>
          </form>
        </div>
      </main>
      <Footer />
    </>
  );
}
