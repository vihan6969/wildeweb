'use server';

import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';

export async function loginAction(prevState: { error: string }, formData: FormData) {
  const key = formData.get('key');

  if (key === process.env.ADMIN_KEY) {
    const cookieStore = await cookies();
    cookieStore.set('admin_session', 'authenticated', {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      path: '/',
      maxAge: 60 * 60 * 24 * 7, // 1 week
    });
    
    redirect('/admin/docs');
  } else {
    return { error: 'Invalid key' };
  }
}
