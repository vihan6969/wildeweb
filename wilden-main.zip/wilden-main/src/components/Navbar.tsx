'use client';

import { useState } from 'react';
import Link from 'next/link';

export function Navbar() {
  const [isNavbarActive, setIsNavbarActive] = useState(false);

  const toggleNavbar = () => setIsNavbarActive(!isNavbarActive);

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <div className="navbar-brand">
          <Link href="/" className="navbar-logo">
            <img src="/media/small_logo.png" alt="Wilden Logo" className="navbar-logo-img" />
          </Link>
        </div>

        <div className={`navbar-menu ${isNavbarActive ? 'active' : ''}`} id="navbar-menu">
          <div className="navbar-nav">
            <Link href="/#features" className="navbar-link">Store</Link>
            <Link href="/news" className="navbar-link">News</Link>
            <Link href="/map" className="navbar-link">Map</Link>
            <Link href="/docs/player" className="navbar-link" prefetch={true}>Docs</Link>
          </div>
        </div>

        <button className={`navbar-toggle ${isNavbarActive ? 'active' : ''}`} id="navbar-toggle" onClick={toggleNavbar}>
          <span className="navbar-toggle-line"></span>
          <span className="navbar-toggle-line"></span>
          <span className="navbar-toggle-line"></span>
        </button>
      </div>
    </nav>
  );
}
