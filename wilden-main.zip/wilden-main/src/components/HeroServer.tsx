'use client';

import { useState } from 'react';

export function HeroServer() {
  const [isCopied, setIsCopied] = useState(false);

  const copyServerIP = () => {
    const serverIP = 'wilden.fun';
    navigator.clipboard.writeText(serverIP).then(() => {
      setIsCopied(true);
      setTimeout(() => {
        setIsCopied(false);
      }, 2000);
    });
  };

  return (
    <div className="hero-server">
      <div className={`server-info ${isCopied ? 'copied' : ''}`} onClick={copyServerIP}>
        <div className="server-ip">wilden.fun</div>
        <div className="server-label">{isCopied ? 'Copied!' : 'Click to copy'}</div>
      </div>
    </div>
  );
}
