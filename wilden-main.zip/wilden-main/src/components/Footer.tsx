import Link from 'next/link';

export function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-content">
          <div className="footer-brand">
            <img src="/media/logo.webp" alt="Wilden" className="footer-logo" />
            <p className="footer-description">The ultimate Minecraft server experience.</p>
          </div>
          <div className="footer-links">
            <div className="footer-section">
              <h4 className="footer-title">Server</h4>
              <Link href="/#features" className="footer-link">Store</Link>
              <Link href="/news" className="footer-link">News</Link>
              <Link href="/#join" className="footer-link">How to Join</Link>
            </div>
            <div className="footer-section">
              <h4 className="footer-title">Community</h4>
              <Link href="https://discord.gg/wilden" className="footer-link">Discord</Link>
              <Link href="/#about" className="footer-link">Team</Link>
              <Link href="/#features" className="footer-link">Features</Link>
            </div>
          </div>
        </div>
        <div className="footer-bottom">
          <p>&copy; 2024 Wilden. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
