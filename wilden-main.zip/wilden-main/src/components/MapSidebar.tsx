'use client';

import { useEffect, useState } from 'react';
import { fetchOnlinePlayers } from '@/app/map/actions';

interface Player {
  uuid: string;
  name: string;
  display_name: string;
  world: string;
  x: number;
  z: number;
}

export function MapSidebar({ onPlayerClick }: { onPlayerClick: (p: Player) => void }) {
  const [players, setPlayers] = useState<Player[]>([]);
  const [max, setMax] = useState(0);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const fetchPlayers = async () => {
      try {
        const data = await fetchOnlinePlayers();
        setPlayers(data.players || []);
        setMax(data.max || 0);
      } catch (err) {
        console.error('Failed to fetch players', err);
      }
    };

    fetchPlayers();
    const interval = setInterval(fetchPlayers, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <>
      {/* Mobile Toggle Button */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="md:hidden absolute top-[90px] right-4 z-[30] bg-[var(--card-bg)]/80 backdrop-blur-md border border-[var(--border-color)] text-[var(--text-primary)] p-2 rounded-md shadow-md pointer-events-auto transition-colors hover:text-[var(--accent-primary)] hover:border-[var(--accent-border)]"
        aria-label="Toggle Players Sidebar"
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
          <circle cx="9" cy="7" r="4"></circle>
          <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
          <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
        </svg>
      </button>

      {/* Sidebar Overlay for Mobile */}
      {isOpen && (
        <div 
          className="md:hidden absolute inset-0 bg-black/50 z-[25] pointer-events-auto transition-opacity"
          onClick={() => setIsOpen(false)}
        />
      )}

      <div className={`absolute right-0 top-0 bottom-0 w-64 bg-[var(--card-bg)]/80 backdrop-blur-md border-l border-[var(--border-color)] overflow-y-auto flex flex-col pointer-events-auto shadow-2xl z-[30] transition-transform duration-300 ${isOpen ? 'translate-x-0' : 'translate-x-full md:translate-x-0'}`}>
        <div className="p-4 border-b border-[var(--border-color)] sticky top-0 bg-[var(--card-bg)]/90 backdrop-blur-sm flex justify-between items-center">
          <div>
            <h3 className="font-bold text-[var(--text-primary)]">Players Online</h3>
            <p className="text-xs text-[var(--text-secondary)]">{players.length} / {max}</p>
          </div>
          <button 
            onClick={() => setIsOpen(false)} 
            className="md:hidden text-[var(--text-secondary)] hover:text-[var(--accent-primary)] transition-colors p-1"
            aria-label="Close Sidebar"
          >
             <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
          </button>
        </div>
      <div className="flex flex-col p-2 gap-2">
        {players.map(player => {
          const isOverworld = player.world === 'minecraft_overworld';
          return (
            <button
              key={player.uuid || player.name}
              onClick={() => isOverworld && onPlayerClick(player)}
              disabled={!isOverworld}
              className={`flex items-center gap-3 p-2 rounded-md transition-colors text-left ${
                isOverworld 
                  ? 'hover:bg-[var(--secondary-bg)] cursor-pointer opacity-100' 
                  : 'opacity-50 cursor-not-allowed'
              }`}
            >
              <img 
                src={`https://mc-heads.net/avatar/${player.name}/32`} 
                alt={player.name} 
                className="w-8 h-8 rounded-sm bg-[var(--primary-bg)] border border-[var(--border-color)]"
              />
              <div className="flex flex-col overflow-hidden">
                <span className="font-medium text-sm text-[var(--text-primary)] truncate">{player.name}</span>
                <span className="text-[10px] text-[var(--text-secondary)] capitalize truncate">
                  {player.world.replace('minecraft_', '').replace('the_', '')}
                </span>
              </div>
            </button>
          );
        })}
        {players.length === 0 && (
          <p className="text-sm text-[var(--text-secondary)] p-2 text-center mt-4">No players online</p>
        )}
      </div>
    </div>
    </>
  );
}
