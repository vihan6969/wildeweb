import type { BaseLayoutProps } from 'fumadocs-ui/layouts/shared';
import { appName, gitConfig } from './shared';

export function baseOptions(): BaseLayoutProps {
  return {
    nav: {
      title: (
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <img src="/media/logo.webp" alt="Wilden Logo" style={{ width: '24px', height: '24px' }} />
          <span style={{ color: 'var(--accent-primary)', fontWeight: 'bold' }}>Wilden</span>
        </div>
      ),
    },
    githubUrl: `https://github.com/${gitConfig.user}/${gitConfig.repo}`,
  };
}
