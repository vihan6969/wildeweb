fetch('https://map.wilden.fun/assets/index-B3PRV0t1.css').then(r=>r.text()).then(t=>console.log(t.match(/\.[a-zA-Z0-9_-]*link[a-zA-Z0-9_-]*/gi))).catch(console.error)
