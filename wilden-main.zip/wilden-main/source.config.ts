import { defineConfig, defineDocs } from 'fumadocs-mdx/config';
import { metaSchema, pageSchema } from 'fumadocs-core/source/schema';
import { z } from 'zod';

// You can customize Zod schemas for frontmatter and `meta.json` here
// see https://fumadocs.dev/docs/mdx/collections
export const docs = defineDocs({
  dir: 'content/docs',
  docs: {
    schema: pageSchema,
    postprocess: {
      includeProcessedMarkdown: true,
    },
  },
  meta: {
    schema: metaSchema,
  },
});

export const adminDocs = defineDocs({
  dir: 'content/admin-docs',
  docs: {
    schema: pageSchema,
    postprocess: {
      includeProcessedMarkdown: true,
    },
  },
  meta: {
    schema: metaSchema,
  },
});

export const news = defineDocs({
  dir: 'content/news',
  docs: {
    schema: pageSchema.extend({
      image: z.string(),
      description: z.string(),
      date: z.string().or(z.date()),
    }),
  },
});

export default defineConfig({
  mdxOptions: {
    // MDX options
  },
});
