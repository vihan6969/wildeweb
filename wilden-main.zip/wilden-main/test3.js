fetch('https://map.wilden.fun/assets/index-Ug_lD-Kt.js').then(r=>r.text()).then(t=>console.log(t.substring(0, 100000).match(/hash.*split\(/gi))).catch(console.error)
