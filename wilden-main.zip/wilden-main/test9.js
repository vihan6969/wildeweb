fetch('https://map.wilden.fun/assets/index-Ug_lD-Kt.js').then(r=>r.text()).then(t=>{ console.log('squaremap:', t.includes('squaremap')); }).catch(console.error)
