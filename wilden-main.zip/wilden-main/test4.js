fetch('http://localhost:3000/map-api/tiles/settings.json').then(r=>r.json()).then(console.log).catch(console.error)
