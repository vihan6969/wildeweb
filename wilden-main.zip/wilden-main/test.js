fetch('https://map.wilden.fun/assets/index-Ug_lD-Kt.js').then(r=>r.text()).then(t=>console.log(t.match(/[a-zA-Z0-9_-]*link[a-zA-Z0-9_-]*/gi))).catch(console.error)
