fetch('https://map.wilden.fun/assets/index-Ug_lD-Kt.js').then(r=>r.text()).then(t=>{ console.log('flyTo:', t.includes('flyTo')); }).catch(console.error)
