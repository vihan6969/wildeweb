const puppeteer = require('puppeteer');
(async () => {
  const browser = await puppeteer.launch();
  const page = await browser.newPage();
  await page.goto('http://localhost:3000/map', {waitUntil: 'networkidle2'});
  const mapFrame = page.frames().find(f => f.url().includes('map-api'));
  if(mapFrame) {
    // Wait for map to load
    await new Promise(r => setTimeout(r, 2000));
    const url = await mapFrame.evaluate(() => window.location.href);
    console.log('Original URL:', url);
  }
  await browser.close();
})();
