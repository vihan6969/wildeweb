fetch('https://map.wilden.fun/assets/index-Ug_lD-Kt.js').then(r=>r.text()).then(t=>{ console.log('unproject:', t.match(/unproject/g).length); }).catch(console.error)
