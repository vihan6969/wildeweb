import { createMDX } from 'fumadocs-mdx/next';

const withMDX = createMDX();

/** @type {import('next').NextConfig} */
const config = {
  reactStrictMode: true,
  devIndicators: {
    appIsrStatus: false,
    buildActivity: false,
  },
  async rewrites() {
    return [
      {
        source: '/map-api/:path*',
        destination: 'https://map.wilden.fun/:path*',
      },
    ];
  },
  async redirects() {
    return [
      {
        source: '/admin/docs',
        destination: '/admin/docs/server-quests/introduction',
        permanent: false,
      },
    ];
  },
};

export default withMDX(config);
